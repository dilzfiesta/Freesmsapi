<?php
	/*
	 * This is a PHP library that handles sending SMS via Freesmsapi Widget.
	 *	
	 * Copyright (c) 2010 Freesmsapi -- http://www.freesmsapi.com
	 * AUTHOR:
	 *   Mohtashim Shaikh
	 *
	 * Permission is hereby granted, free of charge, to any person obtaining a copy
	 * of this software and associated documentation files (the "Software"), to deal
	 * in the Software without restriction, including without limitation the rights
	 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	 * copies of the Software, and to permit persons to whom the Software is
	 * furnished to do so, subject to the following conditions:
	 *
	 * The above copyright notice and this permission notice shall be included in
	 * all copies or substantial portions of the Software.
	 *
	 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	 * THE SOFTWARE.
	 */

	require_once('freesmsapi_lib.php');
	
	$freesmsapi_step = 1;
	$response = '';
	
	/*	Check if Send SMS Form has been submitted	*/
	if(isset($_POST['freesmsapi_message'])) {

		/*	Check for Cross Site Request Forgery	*/
		if($_POST['csrftoken'] == $_SESSION['FREESMSAPI_CSRF_TOKEN']) {
			
			$_POST['freesmsapi_message'] = trim($_POST['freesmsapi_message']);
			if(empty($_POST['freesmsapi_message'])) {
				$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Message is required";
				$freesmsapi_step = 1;

			} else {
				$response = freesmsapi_send_sms($_SERVER["REMOTE_ADDR"], $_POST["freesmsapi_from"], $_POST["freesmsapi_to"], $_POST["freesmsapi_message"], "");
				if($response) {
					list($code, $resp) = explode(FREESMSAPI_RESPONSE_SEPERATOR, $response);
					$freesmsapi_step = $code;
				} else {
					$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Internal Server Error";
					$freesmsapi_step = 1;
				}
			}
			
		} else {
			$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Invalid CSRF Token";
			$freesmsapi_step = 1;
		}
		
		
	
	} else if(isset($_POST['freesmsapi_vcode'])) {

		/*	Check for Cross Site Request Forgery	*/
		if($_POST['csrftoken'] == $_SESSION['FREESMSAPI_CSRF_TOKEN']) {
			
			$_POST['freesmsapi_message'] = trim($_POST['freesmsapi_vcode']);
			if(empty($_POST['freesmsapi_vcode'])) {
				$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Verification code is required";
				$freesmsapi_step = 2;
			}
			
			$response = freesmsapi_send_sms($_SERVER["REMOTE_ADDR"], "", "", "", $_POST['freesmsapi_vcode']);
			if($response) {
				list($code, $resp) = explode(FREESMSAPI_RESPONSE_SEPERATOR, $response);
				$freesmsapi_step = $code;
			} else {
				$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Error occured while sending SMS";
				$freesmsapi_step = 1;
			}
			
		} else {
			$response = "0".FREESMSAPI_RESPONSE_SEPERATOR."Invalid CSRF Token";
			$freesmsapi_step = 2;
		}
		
	
	}
	
	$freesmsapi_response = freesmsapi_render_response($response);
	
?>
