<?php
	require_once('freesmsapi_lib.php');

	/*	Check if Send SMS Form has been submitted	*/
	if(isset($_POST['freesmsapi_widget_d_is'])) {

		/*	Check for Cross Site Request Forgery	*/
		if($_POST['csrftoken'] == $_SESSION['FREESMSAPI_CSRF_TOKEN']) {
			
			/*	Send SMS	*/
			$response = freesmsapi_send_sms($_SERVER["REMOTE_ADDR"], $_POST["freesmsapi_to"], $_POST["freesmsapi_message"]);
			if($response) {
				echo $response;
			}
		} else {
			echo 'Invalid Request';
		}
	}

	/*	Fetch FreeSMSAPI Widget HTML	*/
	$freesmsapi_html = freesmsapi_get_html();
	
?>
<html>
	<body>
		<?php echo $freesmsapi_html; ?>
	</body>
</html>
