<?php
	/*
	 * This is a PHP library that handles sending SMS via Freesmsapi Widget.
	 *	
	 * Copyright (c) 2010 Freesmsapi -- http://www.freesmsapi.com
	 * AUTHORS:
	 *   Mohtashim Shaikh
	 *
	 * Permission is hereby granted, free of charge, to any person obtaining a copy
	 * of this software and associated documentation files (the "Software"), to deal
	 * in the Software without restriction, including without limitation the rights
	 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	 * copies of the Software, and to permit persons to whom the Software is
	 * furnished to do so, subject to the following conditions:
	 *
	 * The above copyright notice and this permission notice shall be included in
	 * all copies or substantial portions of the Software.
	 *
	 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	 * THE SOFTWARE.
	 */

	require_once("freesmsapi_config.php");
	
	/**
	 * The Freesmsapi server URL's
	 */
	define("FREESMSAPI_GET_HTML", "http://www.freesmsapi.com/widgets/get_html");
	define("FREESMSAPI_SMS_SERVER", "http://www.freesmsapi.com/widgets/send_sms");

	/**
	 * Encodes the given data into a query string format
	 * @param $data - array of string elements to be encoded
	 * @return string - encoded request
	 */
	function _freesmsapi_qsencode ($data) {
		$req = "";
		foreach ( $data as $key => $value )
		        $req .= $key . '=' . urlencode( stripslashes($value) ) . '&';

		// Cut the last '&'
		$req=substr($req,0,strlen($req)-1);
		return $req;
	}

	/**
	 * Fetch Widget's HTML Content
	 * @param None
	 * @return string - Widget HTML
	 */
	function freesmsapi_get_html () {
		
		//To avoid Cross Site Request Forgery
		$csrftoken = rand(99,99999);
		$_SESSION['FREESMSAPI_CSRF_TOKEN'] = $csrftoken;

		$data['csrftoken'] = $csrftoken;
		$data['secretkey'] = FREESMSAPI_SECRET_KEY;
		$data['submitpath'] = FREESMSAPI_SUBMIT_PATH;
		$host = FREESMSAPI_GET_HTML;
		$req = _freesmsapi_qsencode ($data);
		return file_get_contents (FREESMSAPI_GET_HTML."?".$req);
	}

	/**
	 * Send SMS using Widget
	 * @param $client_ip
	 * @param $recipient
	 * @param $message
	 * @return XML - Success or failure message
	 */
	function freesmsapi_send_sms ($client_ip, $recipient, $message) {
		$data['client_ip'] = $client_ip;
		$data['recipient'] = $recipient;
		$data['message'] = $message;
		$data['skey'] = FREESMSAPI_SECRET_KEY;
		$data['senderid'] = FREESMSAPI_SENDER_ID;
		$req = _freesmsapi_qsencode ($data);
		return file_get_contents (FREESMSAPI_SMS_SERVER."?".$req);
	}
?>

