<?php
	@session_start();

	/*	Change this with your Secret Key	*/
	define("FREESMSAPI_SECRET_KEY", "YOUR SECRET KEY");

	/*	Change this with your Sender ID (If any or else leave it as it is)	*/
	define("FREESMSAPI_SENDER_ID", "fsmsapi");

	/* Provide absolute path to freesmsapi_send.php file	
	 * eg: http://www.yoursite.com/path/to/freesmsapi_send.php
	**/
	define("FREESMSAPI_SUBMIT_PATH", "http://yoursite/freesmsapi_widget/freesmsapi_send.php");

?>

